package com.am.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.am.Entity.Employee;
import com.am.repo.EmployeeRepo;

@Service
public class EmpServiceImpl implements EmpService{

	@Autowired
	private EmployeeRepo empRepo;
	
	
	public EmpServiceImpl(EmployeeRepo empRepo) {
		
		this.empRepo = empRepo;
	}

	@Override
	public Employee addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return empRepo.save(emp);
	}

	@Override
	public Optional<Employee> getEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return empRepo.findById(emp.getId());
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return empRepo.findAll();
	}

	@Override
	public void deleteEmployee(Employee emp) {
		// TODO Auto-generated method stub
		empRepo.delete(emp);
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		return empRepo.save(emp);
	}
	
	
}
