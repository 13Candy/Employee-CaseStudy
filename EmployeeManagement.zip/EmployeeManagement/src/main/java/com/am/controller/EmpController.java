package com.am.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.am.Entity.Employee;
import com.am.service.EmpServiceImpl;

@RestController
public class EmpController {
	@Autowired
	private EmpServiceImpl empServ;
	
	@GetMapping("/get")
	public Optional<Employee> getEmp(@RequestBody Employee emp) {
		return empServ.getEmployee(emp);
	}
	
	@GetMapping("/getAll")
	public List<Employee> getAllEmp()
	{
		return empServ.getAllEmployee();
	}
	
	@PostMapping("/add")
	public String addEmp(@RequestBody Employee emp)
	{
		empServ.addEmployee(emp);
		return "Employee added Successfullly !!!";
	}
	
	@PutMapping("/update")
	public Employee updEmp(@RequestBody Employee emp)
	{
		return empServ.updateEmployee(emp);
	}
	
	@DeleteMapping("/delete")
	public void deleteEmp(@RequestBody Employee emp)
	{
		empServ.deleteEmployee(emp);
	}
}
