package com.am.service;

import java.util.List;
import java.util.Optional;

import com.am.Entity.Employee;



public interface EmpService {
	public Employee addEmployee(Employee emp);
	public Optional<Employee> getEmployee(Employee emp);
	public List<Employee> getAllEmployee();
	public void deleteEmployee(Employee emp);
	public Employee updateEmployee(Employee emp);
}
